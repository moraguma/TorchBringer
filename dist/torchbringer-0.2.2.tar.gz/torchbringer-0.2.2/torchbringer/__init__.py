"""
TorchBringer

A PyTorch library for deep reinforcement learning 
"""

__version__ = "0.2.2"
__author__ = 'Moraguma'
__credits__ = ''
