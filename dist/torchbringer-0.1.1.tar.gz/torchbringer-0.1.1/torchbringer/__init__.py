"""
TorchBringer

A PyTorch library for deep reinforcement learning 
"""

__version__ = "0.1.1"
__author__ = 'Moraguma'
__credits__ = ''
