"""
TorchBringer

A PyTorch library for deep reinforcement learning 
"""

__version__ = "0.3.4"
__author__ = 'Moraguma'
__credits__ = ''
